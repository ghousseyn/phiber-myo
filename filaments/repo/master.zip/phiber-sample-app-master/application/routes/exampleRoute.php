<?php
return array(
    array('~/info/(\d+)/(\d+)~'=>'/myo/index/main/:cat/:id'),
    array('~/infos~'=>'/myo/myo'),
    array('~/عربي/(\d+)/(\d+)~'=>'/myo/index/main/:cat/:id')
);