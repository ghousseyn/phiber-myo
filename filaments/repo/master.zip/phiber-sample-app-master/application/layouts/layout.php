here
<?php
//var assigned within the sample plugin
echo $this->var;