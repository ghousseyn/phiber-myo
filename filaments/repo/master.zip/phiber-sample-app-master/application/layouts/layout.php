<?php
//var assigned within the sample plugin
$this->render();