<?php
T_($this->text);