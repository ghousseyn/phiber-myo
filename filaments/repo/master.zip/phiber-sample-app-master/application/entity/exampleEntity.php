<?php
namespace entity;
use Phiber;

class exampleEntity extends Phiber\entity\entity
{

}