<?php
namespace model;
use Phiber;
use entity;

class exampleModel extends Phiber\model
{

}