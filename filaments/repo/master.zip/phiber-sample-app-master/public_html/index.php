<?php

include "../vendor/phiber/phiber/library/phiber.php";

$phiber = Phiber\phiber::getInstance();

$phiber->run('../application/config.php');

?>

